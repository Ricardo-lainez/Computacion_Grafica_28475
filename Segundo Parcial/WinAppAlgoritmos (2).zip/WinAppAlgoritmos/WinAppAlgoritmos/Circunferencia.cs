﻿using System;
using System.Windows.Forms;

namespace WinAppAlgoritmos
{
    public partial class Circunferencia : Form
    {
        private CCircunferencia ObjCircunferencia = new CCircunferencia();

        public Circunferencia()
        {
            InitializeComponent();
            if (ptbGrafica != null)
                ptbGrafica.BackColor = System.Drawing.Color.White;

            ConfigurarValidaciones();
        }

        private void ConfigurarValidaciones()
        {
            txtRadio.KeyPress += TextBox_KeyPress;
        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Circunferencia_Load(object sender, EventArgs e)
        {
            ObjCircunferencia.InitializeData(txtRadio, ptbGrafica);

            int maxRadius = Math.Min((ptbGrafica.Width / 5) / 2, (ptbGrafica.Height / 5) / 2) - 1;
            this.Text = $"Circunferencia - Radio máximo: {maxRadius}";
        }

        private void btnGraficar_Click(object sender, EventArgs e)
        {
            if (ObjCircunferencia.ReadData(txtRadio, ptbGrafica))
            {
                ObjCircunferencia.CalculateCircle(ptbGrafica);
                ObjCircunferencia.DrawComplete(ptbGrafica);
            }
        }

    }
}
