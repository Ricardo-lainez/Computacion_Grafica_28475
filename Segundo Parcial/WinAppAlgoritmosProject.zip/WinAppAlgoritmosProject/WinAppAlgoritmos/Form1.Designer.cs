﻿namespace WinAppAlgoritmos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aLGORITMOSDELINEAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMODDAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMOBRESENHAMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMOPUNTOMEDIOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMOPOLINOMICOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMOTRIGONOMETRICOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aLGORITMODERELLENOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aLGORITMOSDELINEAToolStripMenuItem,
            this.aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem,
            this.aLGORITMODERELLENOToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aLGORITMOSDELINEAToolStripMenuItem
            // 
            this.aLGORITMOSDELINEAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aLGORITMODDAToolStripMenuItem,
            this.aLGORITMOBRESENHAMToolStripMenuItem,
            this.aLGORITMOPUNTOMEDIOToolStripMenuItem});
            this.aLGORITMOSDELINEAToolStripMenuItem.Name = "aLGORITMOSDELINEAToolStripMenuItem";
            this.aLGORITMOSDELINEAToolStripMenuItem.Size = new System.Drawing.Size(144, 20);
            this.aLGORITMOSDELINEAToolStripMenuItem.Text = "ALGORITMOS DE LINEA";
            // 
            // aLGORITMODDAToolStripMenuItem
            // 
            this.aLGORITMODDAToolStripMenuItem.Name = "aLGORITMODDAToolStripMenuItem";
            this.aLGORITMODDAToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.aLGORITMODDAToolStripMenuItem.Text = "ALGORITMO DDA";
            this.aLGORITMODDAToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMODDAToolStripMenuItem_Click);
            // 
            // aLGORITMOBRESENHAMToolStripMenuItem
            // 
            this.aLGORITMOBRESENHAMToolStripMenuItem.Name = "aLGORITMOBRESENHAMToolStripMenuItem";
            this.aLGORITMOBRESENHAMToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.aLGORITMOBRESENHAMToolStripMenuItem.Text = "ALGORITMO BRESENHAM";
            this.aLGORITMOBRESENHAMToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMOBRESENHAMToolStripMenuItem_Click);
            // 
            // aLGORITMOPUNTOMEDIOToolStripMenuItem
            // 
            this.aLGORITMOPUNTOMEDIOToolStripMenuItem.Name = "aLGORITMOPUNTOMEDIOToolStripMenuItem";
            this.aLGORITMOPUNTOMEDIOToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.aLGORITMOPUNTOMEDIOToolStripMenuItem.Text = "ALGORITMO PUNTO MEDIO";
            this.aLGORITMOPUNTOMEDIOToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMOPUNTOMEDIOToolStripMenuItem_Click);
            // 
            // aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem
            // 
            this.aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem,
            this.aLGORITMOPOLINOMICOToolStripMenuItem,
            this.aLGORITMOTRIGONOMETRICOToolStripMenuItem});
            this.aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem.Name = "aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem";
            this.aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem.Size = new System.Drawing.Size(208, 20);
            this.aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem.Text = "ALGORITMOS DE CIRCUNFERENCIA";
            // 
            // aLGORITMOSIMETRIA8LADOSToolStripMenuItem
            // 
            this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem.Name = "aLGORITMOSIMETRIA8LADOSToolStripMenuItem";
            this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem.Text = "ALGORITMO SIMETRIA 8 LADOS";
            this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMOSIMETRIA8LADOSToolStripMenuItem_Click_1);
            // 
            // aLGORITMOPOLINOMICOToolStripMenuItem
            // 
            this.aLGORITMOPOLINOMICOToolStripMenuItem.Name = "aLGORITMOPOLINOMICOToolStripMenuItem";
            this.aLGORITMOPOLINOMICOToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.aLGORITMOPOLINOMICOToolStripMenuItem.Text = "ALGORITMO POLINOMICO";
            this.aLGORITMOPOLINOMICOToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMOPOLINOMICOToolStripMenuItem_Click);
            // 
            // aLGORITMOTRIGONOMETRICOToolStripMenuItem
            // 
            this.aLGORITMOTRIGONOMETRICOToolStripMenuItem.Name = "aLGORITMOTRIGONOMETRICOToolStripMenuItem";
            this.aLGORITMOTRIGONOMETRICOToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.aLGORITMOTRIGONOMETRICOToolStripMenuItem.Text = "ALGORITMO TRIGONOMETRICO";
            this.aLGORITMOTRIGONOMETRICOToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMOTRIGONOMETRICOToolStripMenuItem_Click);
            // 
            // aLGORITMODERELLENOToolStripMenuItem
            // 
            this.aLGORITMODERELLENOToolStripMenuItem.Name = "aLGORITMODERELLENOToolStripMenuItem";
            this.aLGORITMODERELLENOToolStripMenuItem.Size = new System.Drawing.Size(154, 20);
            this.aLGORITMODERELLENOToolStripMenuItem.Text = "ALGORITMO DE RECORTE";
            this.aLGORITMODERELLENOToolStripMenuItem.Click += new System.EventHandler(this.aLGORITMODERELLENOToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOSDELINEAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMODDAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOBRESENHAMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOPUNTOMEDIOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOSDECIRCUNFERENCIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOSIMETRIA8LADOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMODERELLENOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOPOLINOMICOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aLGORITMOTRIGONOMETRICOToolStripMenuItem;
    }
}

