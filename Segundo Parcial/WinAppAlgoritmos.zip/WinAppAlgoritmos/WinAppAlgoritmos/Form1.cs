﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinAppAlgoritmos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CerrarFormulariosHijos()
        {
            foreach (Form childForm in this.MdiChildren)
            {
                childForm.Close();
            }
        }

        private void dDAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarFormulariosHijos();
            DDA DDA = new DDA();
            DDA.MdiParent = this;
            DDA.WindowState = FormWindowState.Maximized;
            DDA.Show();
        }

        private void bresenhamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarFormulariosHijos();
            Bresenham Bresenham = new Bresenham();
            Bresenham.MdiParent = this;
            Bresenham.WindowState = FormWindowState.Maximized;
            Bresenham.Show();
        }

        private void puntoMedioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarFormulariosHijos();
            PMedio PuntoMedio = new PMedio();
            PuntoMedio.MdiParent = this;
            PuntoMedio.WindowState = FormWindowState.Maximized;
            PuntoMedio.Show();
        }
    }
}
